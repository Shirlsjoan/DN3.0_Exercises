package Week_1;

public class Computer {
    private String CPU;
    private String RAM;
    private String storage;
    private String GPU;
    private String operatingSystem;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.GPU = builder.GPU;
        this.operatingSystem = builder.operatingSystem;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", storage=" + storage + 
               ", GPU=" + GPU + ", operatingSystem=" + operatingSystem + "]";
    }

    public static class Builder {
        private String CPU;
        private String RAM;
        private String storage;
        private String GPU;
        private String operatingSystem;

        public Builder(String CPU, String RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }

        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGPU(String GPU) {
            this.GPU = GPU;
            return this;
        }

        public Builder setOperatingSystem(String operatingSystem) {
            this.operatingSystem = operatingSystem;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    public static void main(String[] args) {
        Computer gamingPC = new Builder("Intel i9", "32GB")
                                    .setStorage("1TB SSD")
                                    .setGPU("NVIDIA RTX 3080")
                                    .setOperatingSystem("Windows 10")
                                    .build();

        Computer officePC = new Builder("Intel i5", "16GB")
                                    .setStorage("512GB SSD")
                                    .setOperatingSystem("Windows 10")
                                    .build();

        Computer budgetPC = new Builder("AMD Ryzen 3", "8GB")
                                    .setStorage("256GB SSD")
                                    .build();

        System.out.println("Gaming PC: " + gamingPC);
        System.out.println("Office PC: " + officePC);
        System.out.println("Budget PC: " + budgetPC);
    }
}
