package Week_1;
import java.util.ArrayList;
import java.util.Scanner;

public class InventoryManagementSystem {
    private ArrayList<Product> inventory;

    public InventoryManagementSystem() {
        this.inventory = new ArrayList<>();
    }

    private static class Product {
        private String productId;
        private String productName;
        private int quantity;
        private double price;

        public Product(String productId, String productName, int quantity, double price) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        public String getProductId() 
        {
            return productId;
        }

        public void setProductId(String productId)
        {
            this.productId = productId;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) 
        {
            this.productName = productName;
        }

        public int getQuantity() 
        {
            return quantity;
        }

        public void setQuantity(int quantity)
        {
            this.quantity = quantity;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) 
        {
            this.price = price;
        }

        @Override
        public String toString() {
            return "Product Description :" +"productId='" + productId + '\'' +", productName :='" + productName + '\'' + ", quantity :=" + quantity + ", price=" + price;
        }
    }
//add
    public void addProduct(Product product) {
        inventory.add(product);
    }
//update
    public void update(String productId, Product updatedPro) {
        for (int i = 0; i < inventory.size(); i++) {
            Product p = inventory.get(i);
            if (p.getProductId().equals(productId)) {
                inventory.set(i, updatedPro);
                return;
            }
        }
        System.out.println("Product not found in inventory.");
    }

    //deletee
    public void deleteProduct(String productId) {
        inventory.removeIf(product -> product.getProductId().equals(productId));
    }

    //display
    public void displayAllProducts() {
        for (Product p : inventory) {
            System.out.println(p);
        }
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Scanner s = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add product");
            System.out.println("2. Update product");
            System.out.println("3. Delete product");
            System.out.println("4. Display all products");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = s.nextInt();

            switch (option) {
            case 1:
                System.out.print("Enter product ID, name, quantity, and price: ");
                Product product = new Product(s.next(), s.next(), s.nextInt(), s.nextDouble());
                ims.addProduct(product);
                break;
            case 2:
                System.out.print("Enter product ID to update, new name, quantity, and price: ");
                Product updatedProduct = new Product(s.next(), s.next(), s.nextInt(), s.nextDouble());
                ims.update(updatedProduct.getProductId(), updatedProduct);
                break;
            case 3:
                System.out.print("Enter product ID to delete: ");
                ims.deleteProduct(s.next());
                break;
            case 4:
                System.out.println("All products in inventory:");
                ims.displayAllProducts();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option. Please choose a valid option.");
        }
        }
    }
}
