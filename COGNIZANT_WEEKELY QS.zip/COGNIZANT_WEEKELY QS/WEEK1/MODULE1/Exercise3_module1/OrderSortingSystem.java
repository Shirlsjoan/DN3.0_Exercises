package Week_1;

public class OrderSortingSystem {

    public static class Order {
        private String orderId;
        private String customerName;
        private double totalPrice;

        public Order(String orderId, String customerName, double totalPrice) {
            this.orderId = orderId;
            this.customerName = customerName;
            this.totalPrice = totalPrice;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        @Override
        public String toString() {
            return "Order{" +
                    "orderId='" + orderId + '\'' +
                    ", customerName='" + customerName + '\'' +
                    ", totalPrice=" + totalPrice +
                    '}';
        }
    }

    public void bubbleSortOrders(Order[] orders) {
        for (int i = 0; i < orders.length - 1; i++) {
            for (int j = 0; j < orders.length - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public void quickSortOrders(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSortOrders(orders, low, pi - 1);
            quickSortOrders(orders, pi + 1, high);
        }
    }

    private int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void main(String[] args) {
        Order[] orders = {
            new Order("001", "Alice", 250.0),
            new Order("002", "Bob", 150.0),
            new Order("003", "Charlie", 300.0),
            new Order("004", "David", 200.0)
        };

        OrderSortingSystem sortingSystem = new OrderSortingSystem();

        System.out.println("Original Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        Order[] bubbleSorted= orders.clone();
        sortingSystem.bubbleSortOrders(bubbleSorted);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        for (Order order : bubbleSorted) {
            System.out.println(order);
        }

        Order[] quickSorted = orders.clone();
        sortingSystem.quickSortOrders(quickSorted, 0, quickSorted.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        for (Order order : quickSorted) {
            System.out.println(order);
        }
    }
}
