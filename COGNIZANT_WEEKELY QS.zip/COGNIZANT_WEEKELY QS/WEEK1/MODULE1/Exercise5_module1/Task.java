package Week_1;

public class Task {
    private int taskId;
    private String taskName;
    private boolean status;

    public Task(int taskId, String taskName, boolean status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public int getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public boolean isStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId=" + taskId +
                ", taskName='" + taskName + '\'' +
                ", status=" + status +
                '}';
    }
}

 class TaskLinkedList {
    private Node head;

    public TaskLinkedList() {
        head = null;
    }

    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.getNext()!= null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    public Task searchTask(int taskId) {
        Node current = head;
        while (current!= null) {
            if (current.getTask().getTaskId() == taskId) {
                return current.getTask();
            }
            current = current.getNext();
        }
        return null;
    }

    public void traverseTasks() {
        Node current = head;
        while (current!= null) {
            System.out.println(current.getTask());
            current = current.getNext();
        }
    }

    public void deleteTask(int taskId) {
        Node current = head;
        Node previous = null;
        while (current!= null) {
            if (current.getTask().getTaskId() == taskId) {
                if (previous == null) {
                    head = current.getNext();
                } else {
                    previous.setNext(current.getNext());
                }
                return;
            }
            previous = current;
            current = current.getNext();
        }
    }

    private static class Node {
        private Task task;
        private Node next;

        public Node(Task task) {
            this.task = task;
            this.next = null;
        }

        public Task getTask() {
            return task;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }
    }
}
