package Week_1;

 class Book {
    private int bookId;
    private String title;
    private String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                '}';
    }
}

public class Library {
    private Book[] books;

    public Library(Book[] books) {
        this.books = books;
    }

    // Linear search method
    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Book not found
    }
    public static void main(String[] args) {
        Book[] books = new Book[] {
            new Book(1, "To Kill a Mockingbird", "Harper Lee"),
            new Book(2, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(3, "Pride and Prejudice", "Jane Austen")
        };

        Library library = new Library(books);

        Book foundBook = library.linearSearchByTitle("The Great Gatsby");
        if (foundBook!= null) {
            System.out.println("Found book: " + foundBook);
        } else {
            System.out.println("Book not found");
        }
    }
}
