

import java.util.Scanner;

public class FinancialForecastingTool {
    public static double calFutVal(double presValue, double growthRate, int years) {
        if (years == 0) {
            return presValue;
        } else {
            return calFutVal(presValue * (1 + growthRate), growthRate, years - 1);
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Enter the present value: ");
        double presentValue = s.nextDouble();

        System.out.print("Enter the annual growth rate (as a decimal): ");
        double growthRate = s.nextDouble();

        System.out.print("Enter the number of years to predict: ");
        int years = s.nextInt();

        double futureValue = calFutVal(presentValue, growthRate, years);
        System.out.println("Future value after " + years + " years: " + futureValue);
    }
}